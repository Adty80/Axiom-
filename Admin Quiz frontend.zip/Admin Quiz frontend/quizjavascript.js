var drp = document.getElementById('languages');
drp.addEventListener('click', cquiz);
drp.addEventListener('click', cplusquiz);
drp.addEventListener('click', htmlquiz);
drp.addEventListener('click', cssquiz);
drp.addEventListener('click', bootstrapquiz);
drp.addEventListener('click', javascriptquiz);
drp.addEventListener('click', jqueryquiz);
drp.addEventListener('click', ajaxquiz);
drp.addEventListener('click', reactjs);
drp.addEventListener('click', reactnative);
drp.addEventListener('click', angular);
drp.addEventListener('click', laravel);
drp.addEventListener('click', php);
drp.addEventListener('click', flutter);
drp.addEventListener('click', meanstack);
drp.addEventListener('click', tailwindcss);
drp.addEventListener('click', mernstack);
drp.addEventListener('click', github);
drp.addEventListener('click', python);
drp.addEventListener('click', django);
drp.addEventListener('click', java);

// C quiz
function cquiz()
{
    var c = document.getElementById('languages');
    if(c.selectedIndex == 1)
    {
        // first question
        document.getElementById('question1').innerHTML = "Q1. Which operator is used to add together two values?";
        document.getElementById('lblq1choice1').innerHTML = `The + sign`;
        document.getElementById('lblq1choice2').innerHTML = `The * sign`;
        document.getElementById('lblq1choice3').innerHTML = `The ADD Keyword`;
        document.getElementById('lblq1choice4').innerHTML = `None of this`;

        // second question
        document.getElementById('question2').innerHTML = "Q2. Which function is often used to output values and print text?";
        document.getElementById('lblq2choice1').innerHTML = "Write()";
        document.getElementById('lblq2choice2').innerHTML = "Printf()";
        document.getElementById('lblq2choice3').innerHTML = "Output";
        document.getElementById('lblq2choice4').innerHTML = "None of this";

        // third question
        document.getElementById('question3').innerHTML = "Q3. Which format specifier is often used to print integers?";
        document.getElementById('lblq3choice1').innerHTML = "%s";
        document.getElementById('lblq3choice2').innerHTML = "%d";
        document.getElementById('lblq3choice3').innerHTML = "%c";
        document.getElementById('lblq3choice4').innerHTML = "%f"; 

        // fourth question
        document.getElementById('question4').innerHTML = "Q4. Which operator can be used to compare two values?";
        document.getElementById('lblq4choice1').innerHTML = "><";
        document.getElementById('lblq4choice2').innerHTML = "<>";
        document.getElementById('lblq4choice3').innerHTML = "==";
        document.getElementById('lblq4choice4').innerHTML = "None of this";

        // fifth question
        document.getElementById('question5').innerHTML = "Q5. What is the purpose of the 'sizeof' operator in C?";
        document.getElementById('lblq5choice1').innerHTML = "Get the size of a variable";
        document.getElementById('lblq5choice2').innerHTML = "Get the address of a variable";
        document.getElementById('lblq5choice3').innerHTML = "Perform arithematic operations";
        document.getElementById('lblq5choice4').innerHTML = "Calculate Square root";
    
        // sixth question
        document.getElementById('question6').innerHTML = "Q6. What is the difference between a declaration and definition of a variable?";
        document.getElementById('lblq6choice1').innerHTML = "Both can occur multiple times but definition occur first";
        document.getElementById('lblq6choice2').innerHTML = "Definition occurs once but declaration occur many times";
        document.getElementById('lblq6choice3').innerHTML = "Declaration occurs once but definition occur many times";
        document.getElementById('lblq6choice4').innerHTML = "None of this";
    
        //seventh question
        document.getElementById('question7').innerHTML = "Q7. What is the correct syntax for declaring a variable in C?";
        document.getElementById('lblq7choice1').innerHTML = "int variable_name;";
        document.getElementById('lblq7choice2').innerHTML = "variable_name int;";
        document.getElementById('lblq7choice3').innerHTML = "int = variable_name;";
        document.getElementById('lblq7choice4').innerHTML = "variable_name = 5;";

        //Eighth question
        document.getElementById('question8').innerHTML = "Q8. Associativity of an operator is.....";
        document.getElementById('lblq8choice1').innerHTML = "Right to Left";
        document.getElementById('lblq8choice2').innerHTML = "Left to Right";
        document.getElementById('lblq8choice3').innerHTML = "Random Fashion";
        document.getElementById('lblq8choice4').innerHTML = "Both Right to Left and Left to Right";

        //Ninth question
        document.getElementById('question9').innerHTML = "Q9. Which of the following is a ternary operator?";
        document.getElementById('lblq9choice1').innerHTML = "&&";
        document.getElementById('lblq9choice2').innerHTML = ">>=";
        document.getElementById('lblq9choice3').innerHTML = "? :";
        document.getElementById('lblq9choice4').innerHTML = "->";

        //Tenth question
        document.getElementById('question10').innerHTML = "10. For loop in a C program, if the condition is missing";
        document.getElementById('lblq10choice1').innerHTML = "It is assumed to be present and taken to be false";
        document.getElementById('lblq10choice2').innerHTML = "It result in a syntax error";
        document.getElementById('lblq10choice3').innerHTML = "It is assumed to be present and taken to the true";
        document.getElementById('lblq10choice4').innerHTML = "Execution will be terminated abruptly";
    }
}


// C++ quiz
function cplusquiz()
{
    var cplus = document.getElementById('languages');
    if(cplus.selectedIndex == 2)
    {
        // first question
        document.getElementById('question1').innerHTML = "Q1. What is a correct syntax to output `Hello World` in C++?";
        document.getElementById('lblq1choice1').innerHTML = `console.writeline("Hello World");`;
        document.getElementById('lblq1choice2').innerHTML = `printf("Hello World");`;
        document.getElementById('lblq1choice3').innerHTML = `system.out.println("Hello World");`;
        document.getElementById('lblq1choice4').innerHTML = `cout<<"Hello World";`;

        // second question
        document.getElementById('question2').innerHTML = "Q2. How do you insert COMMENTS in C++ code?";
        document.getElementById('lblq2choice1').innerHTML = "// this is comment";
        document.getElementById('lblq2choice2').innerHTML = "# this is comment";
        document.getElementById('lblq2choice3').innerHTML = "! this is comment";
        document.getElementById('lblq2choice4').innerHTML = "/* this is comment";

        // third question
        document.getElementById('question3').innerHTML = "Q3. What is C++?";
        document.getElementById('lblq3choice1').innerHTML = "C++ is an object oriented programming language";
        document.getElementById('lblq3choice2').innerHTML = "C++ is a procedural programming language";
        document.getElementById('lblq3choice3').innerHTML = "C++ supports both procedural and object oriented programming language";
        document.getElementById('lblq3choice4').innerHTML = "C++ is a functional programming language"; 

        // fourth question
        document.getElementById('question4').innerHTML = "Q4. How do you create a variable with numeric value 5?";
        document.getElementById('lblq4choice1').innerHTML = "x=5;";
        document.getElementById('lblq4choice2').innerHTML = "double x=5;";
        document.getElementById('lblq4choice3').innerHTML = "num x=5;";
        document.getElementById('lblq4choice4').innerHTML = "int x=5;";

        // fifth question
        document.getElementById('question5').innerHTML = "Q5. What is meant by a polymorphism in C++?";
        document.getElementById('lblq5choice1').innerHTML = "class having only single form";
        document.getElementById('lblq5choice2').innerHTML = "class having four forms";
        document.getElementById('lblq5choice3').innerHTML = "class having many forms";
        document.getElementById('lblq5choice4').innerHTML = "class having two forms";
    
        // sixth question
        document.getElementById('question6').innerHTML = "Q6. Which of the following is not a type of inheritance?";
        document.getElementById('lblq6choice1').innerHTML = "Multiple";
        document.getElementById('lblq6choice2').innerHTML = "Multilevel";
        document.getElementById('lblq6choice3').innerHTML = "Distributive";
        document.getElementById('lblq6choice4').innerHTML = "Hierarchical";
    
        //seventh question
        document.getElementById('question7').innerHTML = "Q7. Wrapping data and its related functionality into a single entity is known as _____________";
        document.getElementById('lblq7choice1').innerHTML = "Abstraction";
        document.getElementById('lblq7choice2').innerHTML = "Encapsulation";
        document.getElementById('lblq7choice3').innerHTML = "Polymorphism";
        document.getElementById('lblq7choice4').innerHTML = "Modularity";

        //Eighth question
        document.getElementById('question8').innerHTML = "Q8. How access specifiers in Class helps in Abstraction?";
        document.getElementById('lblq8choice1').innerHTML = "They does not helps in any way";
        document.getElementById('lblq8choice2').innerHTML = "They allows us to show only required things to outer world";
        document.getElementById('lblq8choice3').innerHTML = "They help in keeping things together";
        document.getElementById('lblq8choice4').innerHTML = "Abstraction concept is not used in classes";

        //Ninth question
        document.getElementById('question9').innerHTML = "Q9. Which of the following constructors are provided by the C++ compiler if not defined in a class?";
        document.getElementById('lblq9choice1').innerHTML = "Default constructor";
        document.getElementById('lblq9choice2').innerHTML = "Copy constructor";
        document.getElementById('lblq9choice3').innerHTML = "Assignment constructor";
        document.getElementById('lblq9choice4').innerHTML = "All of the mentioned";

        //Tenth question
        document.getElementById('question10').innerHTML = "10. Which of the following offers a programmer the facility of using a specific class object into other classes?";
        document.getElementById('lblq10choice1').innerHTML = "Polymorphism";
        document.getElementById('lblq10choice2').innerHTML = "Abstraction";
        document.getElementById('lblq10choice3').innerHTML = "Inheritance";
        document.getElementById('lblq10choice4').innerHTML = "Composition";
    }
}

// html quiz
function htmlquiz()
{
    var html = document.getElementById('languages');
    if(html.selectedIndex == 3)
    {
        // first question
        document.getElementById('question1').innerHTML = "Q1. HTML stands for ?";
        document.getElementById('lblq1choice1').innerHTML = "HighText Machine Language";
        document.getElementById('lblq1choice2').innerHTML = "HyperText and links Markup Language";
        document.getElementById('lblq1choice3').innerHTML = "HyperText Markup Language";
        document.getElementById('lblq1choice4').innerHTML = "None of these";

        // second question
        document.getElementById('question2').innerHTML = "Q2. HTML tags are enclosed in?";
        document.getElementById('lblq2choice1').innerHTML = "# and #";
        document.getElementById('lblq2choice2').innerHTML = "! and ?";
        document.getElementById('lblq2choice3').innerHTML = "{and}";
        document.getElementById('lblq2choice4').innerHTML = "<>";

        // third question
        document.getElementById('question3').innerHTML = "Q3. Which of the following HTML attribute is used to define inline styles?";
        document.getElementById('lblq3choice1').innerHTML = "style";
        document.getElementById('lblq3choice2').innerHTML = "type";
        document.getElementById('lblq3choice3').innerHTML = "class";
        document.getElementById('lblq3choice4').innerHTML = "None of the above"; 

        // fourth question
        document.getElementById('question4').innerHTML = "Q4. Which ____________ attribute specifies where to open the linked document?";
        document.getElementById('lblq4choice1').innerHTML = "href";
        document.getElementById('lblq4choice2').innerHTML = "link";
        document.getElementById('lblq4choice3').innerHTML = "src";
        document.getElementById('lblq4choice4').innerHTML = "target";

        // fifth question
        document.getElementById('question5').innerHTML = "Q5. Which of the following spans full width of screen?";
        document.getElementById('lblq5choice1').innerHTML = ".container";
        document.getElementById('lblq5choice2').innerHTML = ".control-label";
        document.getElementById('lblq5choice3').innerHTML = ".container-fluid";
        document.getElementById('lblq5choice4').innerHTML = ".collapse-in";
    
        // sixth question
        document.getElementById('question6').innerHTML = "Q6. What are the types of unordered or bulleted list in HTML?";
        document.getElementById('lblq6choice1').innerHTML = "disc, square, triangle";
        document.getElementById('lblq6choice2').innerHTML = "polygon, triangle, circle";
        document.getElementById('lblq6choice3').innerHTML = "disc, circle, square";
        document.getElementById('lblq6choice4').innerHTML = "All of the above";
    
        //seventh question
        document.getElementById('question7').innerHTML = "Q7. The new __________ element is supposed to represent some form of extra details, such as tooltip or revealed region that may be shown to the user?";
        document.getElementById('lblq7choice1').innerHTML = "progress";
        document.getElementById('lblq7choice2').innerHTML = "meter";
        document.getElementById('lblq7choice3').innerHTML = "details";
        document.getElementById('lblq7choice4').innerHTML = "menu";

        //Eighth question
        document.getElementById('question8').innerHTML = "Q8. Calling the ______________ method during both a dragenter and dragover event will indicate that a drop is allowed at that location?";
        document.getElementById('lblq8choice1').innerHTML = "drop";
        document.getElementById('lblq8choice2').innerHTML = "drag";
        document.getElementById('lblq8choice3').innerHTML = "preventDefaut";
        document.getElementById('lblq8choice4').innerHTML = "dataTransfer";

        //Ninth question
        document.getElementById('question9').innerHTML = "Q9. Which of the following is not set with font-style property?";
        document.getElementById('lblq9choice1').innerHTML = "font-style: normal";
        document.getElementById('lblq9choice2').innerHTML = "font-style: italic";
        document.getElementById('lblq9choice3').innerHTML = "font-style: oblique";
        document.getElementById('lblq9choice4').innerHTML = "font-style: capitalize";

        //Tenth question
        document.getElementById('question10').innerHTML = "10. The ____________ parameter identifies a character encoding, which is a method of converting a sequence of bytes into a sequence of characters?";
        document.getElementById('lblq10choice1').innerHTML = "class";
        document.getElementById('lblq10choice2').innerHTML = "element";
        document.getElementById('lblq10choice3').innerHTML = "charset";
        document.getElementById('lblq10choice4').innerHTML = "None of this";
    }
}

    // css quiz
function cssquiz()
{
    var css = document.getElementById('languages');
    if(css.selectedIndex == 4)
    {
        // first question
        document.getElementById('question1').innerHTML = "Q1. What is CSS?";
        document.getElementById('lblq1choice1').innerHTML = " CSS is a style sheet language";
        document.getElementById('lblq1choice2').innerHTML = "CSS is designed to separate the presentation and content, including layout, colors, and fonts";
        document.getElementById('lblq1choice3').innerHTML = "CSS is the language used to style the HTML documents";
        document.getElementById('lblq1choice4').innerHTML = "All of the mentioned";

        // second question
        document.getElementById('question2').innerHTML = "Q2. Are the negative values allowed in padding property?";
        document.getElementById('lblq2choice1').innerHTML = "Yes";
        document.getElementById('lblq2choice2').innerHTML = "Can't say";
        document.getElementById('lblq2choice3').innerHTML = "No";
        document.getElementById('lblq2choice4').innerHTML = "May be";

        // third question
        document.getElementById('question3').innerHTML = "Q3. What is the correct CSS syntax?";
        document.getElementById('lblq3choice1').innerHTML = "body:color=black;";
        document.getElementById('lblq3choice2').innerHTML = "{body:color=black;}";
        document.getElementById('lblq3choice3').innerHTML = "{body;color:black;}";
        document.getElementById('lblq3choice4').innerHTML = "body{color:black;}"; 

        // fourth question
        document.getElementById('question4').innerHTML = "Q4. Which CSS property is used to change the text color of an element?";
        document.getElementById('lblq4choice1').innerHTML = "text-color";
        document.getElementById('lblq4choice2').innerHTML = "color";
        document.getElementById('lblq4choice3').innerHTML = "fgcolor";
        document.getElementById('lblq4choice4').innerHTML = "None of this";

        // fifth question
        document.getElementById('question5').innerHTML = "Q5. Which of the following is the correct way to apply CSS Styles?";
        document.getElementById('lblq5choice1').innerHTML = " in an external CSS file";
        document.getElementById('lblq5choice2').innerHTML = " inside an HTML element";
        document.getElementById('lblq5choice3').innerHTML = " inside the <head> section of an HTML page";
        document.getElementById('lblq5choice4').innerHTML = "  all of the mentioned";
    
        // sixth question
        document.getElementById('question6').innerHTML = "Q6. What does the CSS property “position: relative;” do?";
        document.getElementById('lblq6choice1').innerHTML = "Positions the element absolutely";
        document.getElementById('lblq6choice2').innerHTML = "Positions the element relative to its normal position";
        document.getElementById('lblq6choice3').innerHTML = "Centers the element horizontally";
        document.getElementById('lblq6choice4').innerHTML = "Floats the element to the right";
    
        //seventh question
        document.getElementById('question7').innerHTML = "Q7. How do you make a navigation bar horizontal in CSS?";
        document.getElementById('lblq7choice1').innerHTML = "nav-bar: horizontal;";
        document.getElementById('lblq7choice2').innerHTML = "display: inline;";
        document.getElementById('lblq7choice3').innerHTML = "display: inline-block;";
        document.getElementById('lblq7choice4').innerHTML = "flex-direction: row;";

        //Eighth question
        document.getElementById('question8').innerHTML = "Q8. What is the default value of the 'box-sizing' property?";
        document.getElementById('lblq8choice1').innerHTML = "content-box";
        document.getElementById('lblq8choice2').innerHTML = "border-box";
        document.getElementById('lblq8choice3').innerHTML = "padding-box";
        document.getElementById('lblq8choice4').innerHTML = "margin-box";

        //Ninth question
        document.getElementById('question9').innerHTML = "Q9. What is the use of 'text-align:justify' in CSS?";
        document.getElementById('lblq9choice1').innerHTML = "Stretches the lines so that each line has equal width";
        document.getElementById('lblq9choice2').innerHTML = "Stretches the lines so that each line can be arranged in left alignment";
        document.getElementById('lblq9choice3').innerHTML = "Stretches the lines so that each line can be arranged in right alignment";
        document.getElementById('lblq9choice4').innerHTML = "None of the above";

        //Tenth question
        document.getElementById('question10').innerHTML = "10. What are the valid values for 'position' property?";
        document.getElementById('lblq10choice1').innerHTML = "block, none, fixed, absolute, and static";
        document.getElementById('lblq10choice2').innerHTML = "block, static, fixed, absolute, and sticky";
        document.getElementById('lblq10choice3').innerHTML = "static, relative, fixed, absolute, and none";
        document.getElementById('lblq10choice4').innerHTML = "static, relative, fixed, absolute, and sticky";
    }
}

    //Bootstrap quiz
    function bootstrapquiz()
    {
    var bootstrap = document.getElementById('languages');
    if(bootstrap.selectedIndex == 5)
    {
        // first question
        document.getElementById('question1').innerHTML = "Q1. Which class shapes an image to a circle?";
        document.getElementById('lblq1choice1').innerHTML = ".img-circle";
        document.getElementById('lblq1choice2').innerHTML = ".img-round";
        document.getElementById('lblq1choice3').innerHTML = ".rounded-circle";
        document.getElementById('lblq1choice4').innerHTML = ".img-rounded";

        // second question
        document.getElementById('question2').innerHTML = "Q2. Who developed the bootstrap?";
        document.getElementById('lblq2choice1').innerHTML = "James Gosling";
        document.getElementById('lblq2choice2').innerHTML = "Dennis Ritchie";
        document.getElementById('lblq2choice3').innerHTML = "Mark Jukervich";
        document.getElementById('lblq2choice4').innerHTML = "Mark otto and Jacob Thornton";

        // third question
        document.getElementById('question3').innerHTML = "Q3. Which of the following class in bootstrap is used to create a big box for calling extra attention?";
        document.getElementById('lblq3choice1').innerHTML = ".box";
        document.getElementById('lblq3choice2').innerHTML = ".container-fluid";
        document.getElementById('lblq3choice3').innerHTML = ".container";
        document.getElementById('lblq3choice4').innerHTML = ".jumbotron"; 

        // fourth question
        document.getElementById('question4').innerHTML = "Q4. Which of the following class can be used to make the images and other content in a web page automatically adjusts to fit the size of the screen?";
        document.getElementById('lblq4choice1').innerHTML = ".img-rounded";
        document.getElementById('lblq4choice2').innerHTML = ".img-fluid";
        document.getElementById('lblq4choice3').innerHTML = ".img-circle";
        document.getElementById('lblq4choice4').innerHTML = "None of the above";

        // fifth question
        document.getElementById('question5').innerHTML = "Q5. In Bootstrap, the contents can be placed within which of the following elements?";
        document.getElementById('lblq5choice1').innerHTML = " Columns";
        document.getElementById('lblq5choice2').innerHTML = " Containers";
        document.getElementById('lblq5choice3').innerHTML = " Rows";
        document.getElementById('lblq5choice4').innerHTML = " None of the above";
    
        // sixth question
        document.getElementById('question6').innerHTML = "Q6. Which of the following is correct about the data-title Data attribute of Tooltip Plugin?";        
        document.getElementById('lblq6choice1').innerHTML = " Sets the default title value if the title attribute isn't present.";
        document.getElementById('lblq6choice2').innerHTML = "Defines how the tooltip is triggered.";
        document.getElementById('lblq6choice3').innerHTML = "Defines default content value if the data-content attribute isn't present";
        document.getElementById('lblq6choice4').innerHTML = "Delays showing and hiding the tooltip in ms.";
    
        //seventh question
        document.getElementById('question7').innerHTML = "Q7.  Which of the following bootstrap style is used to create a .pagination?";
        document.getElementById('lblq7choice1').innerHTML = ".breadcrumb";
        document.getElementById('lblq7choice2').innerHTML = ".pagination";
        document.getElementById('lblq7choice3').innerHTML = ".menu";
        document.getElementById('lblq7choice4').innerHTML = "None of the above.";

        //Eighth question
        document.getElementById('question8').innerHTML = "Q8. Which of the following bootstrap style is used to align .nav links, forms, buttons, or text to left or right in a .navbar?";
        document.getElementById('lblq8choice1').innerHTML = ".navbar-align";
        document.getElementById('lblq8choice2').innerHTML = ".navbar-left, .navbar-right";
        document.getElementById('lblq8choice3').innerHTML = ".alignment";
        document.getElementById('lblq8choice4').innerHTML = "None of the above.";

        //Ninth question
        document.getElementById('question9').innerHTML = "Q9. Which of the following bootstrap style is used to add text to .navbar?";
        document.getElementById('lblq9choice1').innerHTML = ".navbar-text";
        document.getElementById('lblq9choice2').innerHTML = ".text";
        document.getElementById('lblq9choice3').innerHTML = ".form-text";
        document.getElementById('lblq9choice4').innerHTML = "None of the above";

        //Tenth question
        document.getElementById('question10').innerHTML = "10. Which of the following is true about bootstrap help text?";
        document.getElementById('lblq10choice1').innerHTML = "Bootstrap form controls have a block level help text that flows with the inputs";
        document.getElementById('lblq10choice2').innerHTML = "To add a full width block of content, use the .help-block after the input";
        document.getElementById('lblq10choice3').innerHTML = "Both (a) and (b) are correct.";
        document.getElementById('lblq10choice4').innerHTML = "None of the above";
    }
}

// Javascript quiz
function javascriptquiz()
{
    var javascript = document.getElementById('languages');
    if(javascript.selectedIndex == 6)
    {
        // first question
        document.getElementById('question1').innerHTML = "Q1. What is JavaScript?";
        document.getElementById('lblq1choice1').innerHTML = "JavaScript is a scripting language used to make the website interactive";
        document.getElementById('lblq1choice2').innerHTML = "JavaScript is an assembly language used to make the website interactive";
        document.getElementById('lblq1choice3').innerHTML = "JavaScript is a compiled language used to make the website interactive";
        document.getElementById('lblq1choice4').innerHTML = "None of the mentioned";

        // second question
        document.getElementById('question2').innerHTML = "Q2. What is the basic difference between JavaScript and Java?";
        document.getElementById('lblq2choice1').innerHTML = "Functions are considered as fields";
        document.getElementById('lblq2choice2').innerHTML = "Functions are values, and there is no hard distinction between methods and fields";
        document.getElementById('lblq2choice3').innerHTML = "Variables are specific";
        document.getElementById('lblq2choice4').innerHTML = "There is no difference";

        // third question
        document.getElementById('question3').innerHTML = "Q3. Which of the following methods/operation does javascript use instead of == and !=?";
        document.getElementById('lblq3choice1').innerHTML = "JavaScript uses equalto()";
        document.getElementById('lblq3choice2').innerHTML = "JavaScript uses equals() and notequals() instead";
        document.getElementById('lblq3choice3').innerHTML = "JavaScript uses bitwise checking";
        document.getElementById('lblq3choice4').innerHTML = " JavaScript uses === and !== instead"; 

        // fourth question
        document.getElementById('question4').innerHTML = "Q4. The word “document” mainly refers to ______________?";
        document.getElementById('lblq4choice1').innerHTML = "Dynamic Information";
        document.getElementById('lblq4choice2').innerHTML = "Static Information";
        document.getElementById('lblq4choice3').innerHTML = "Both Dynamic and Static Information";
        document.getElementById('lblq4choice4').innerHTML = " Temporary information";

        // fifth question
        document.getElementById('question5').innerHTML = "Q5. Which JavaScript method is used to create a new array with array elements that passes a test?";
        document.getElementById('lblq5choice1').innerHTML = " forEach()";
        document.getElementById('lblq5choice2').innerHTML = " map()";
        document.getElementById('lblq5choice3').innerHTML = " forMap()";
        document.getElementById('lblq5choice4').innerHTML = " filter()";
    
        // sixth question
        document.getElementById('question6').innerHTML = "Q6. Which of the following variables takes precedence over the others if the names are the same?";
        document.getElementById('lblq6choice1').innerHTML = "Global variable";
        document.getElementById('lblq6choice2').innerHTML = "The local element";
        document.getElementById('lblq6choice3').innerHTML = "The two of the above";
        document.getElementById('lblq6choice4').innerHTML = "None of the above";
    
        //seventh question
        document.getElementById('question7').innerHTML = "Q7.  In JavaScript the x===y statement implies that:";
        document.getElementById('lblq7choice1').innerHTML = "Both x and y are equal in value, type and reference address as well.";
        document.getElementById('lblq7choice2').innerHTML = "Both are x and y are equal in value only.";
        document.getElementById('lblq7choice3').innerHTML = "Both are equal in the value and data type.";
        document.getElementById('lblq7choice4').innerHTML = "Both are not same at all.";

        //Eighth question
        document.getElementById('question8').innerHTML = "Q8. Which form of event propagation handles the registered container elements??";
        document.getElementById('lblq8choice1').innerHTML = "Event Propagation";
        document.getElementById('lblq8choice2').innerHTML = "Event Registration";
        document.getElementById('lblq8choice3').innerHTML = "Event Capturing";
        document.getElementById('lblq8choice4').innerHTML = "Default Actions";

        //Ninth question
        document.getElementById('question9').innerHTML = "Q9. Which of the following is an array method??";
        document.getElementById('lblq9choice1').innerHTML = "Map";
        document.getElementById('lblq9choice2').innerHTML = "Filter";
        document.getElementById('lblq9choice3').innerHTML = "Reduce";
        document.getElementById('lblq9choice4').innerHTML = "All of these";

        //Tenth question
        document.getElementById('question10').innerHTML = "10. How to pick a document element based on the value of its id attribute?";
        document.getElementById('lblq10choice1').innerHTML = "getElementsbyId()";
        document.getElementById('lblq10choice2').innerHTML = " getElementbyId()";
        document.getElementById('lblq10choice3').innerHTML = "both getElementsbyId() and getElementbyId()";
        document.getElementById('lblq10choice4').innerHTML = " getElement";
    }
}

// Jquery quiz
function jqueryquiz()
{
    var jquery = document.getElementById('languages');
    if(jquery.selectedIndex == 7)
    {
        // first question
        document.getElementById('question1').innerHTML = "Q1. jQuery is a -";
        document.getElementById('lblq1choice1').innerHTML = "JavaScript method";
        document.getElementById('lblq1choice2').innerHTML = "JavaScript library";
        document.getElementById('lblq1choice3').innerHTML = "JSON library";
        document.getElementById('lblq1choice4').innerHTML = "PHP method";

        // second question
        document.getElementById('question2').innerHTML = "Q2. Who developed jQuery, and in which year it was first released?";
        document.getElementById('lblq2choice1').innerHTML = "John Richard in 2001";
        document.getElementById('lblq2choice2').innerHTML = "Mark Bensman in 2004";
        document.getElementById('lblq2choice3').innerHTML = "John Resig in 2006";
        document.getElementById('lblq2choice4').innerHTML = "None of the above";

        // third question
        document.getElementById('question3').innerHTML = "Q3. The correct syntax to set the background color of all h1 elements to yellow in jQuery -";
        document.getElementById('lblq3choice1').innerHTML = `$("h1").style("background-color","yellow");`;
        document.getElementById('lblq3choice2').innerHTML = `$("h1").html("background-color","yellow");`;
        document.getElementById('lblq3choice3').innerHTML = `$("h1").css("background-color","yellow");`;
        document.getElementById('lblq3choice4').innerHTML = `$("h1").layout("background-color","yellow");`; 

        // fourth question
        document.getElementById('question4').innerHTML = "Q4. Which of the following jQuery method is used to set the value of an element?";
        document.getElementById('lblq4choice1').innerHTML = "val() method";
        document.getElementById('lblq4choice2').innerHTML = "setValue() method";
        document.getElementById('lblq4choice3').innerHTML = "content() method";
        document.getElementById('lblq4choice4').innerHTML = "None of the above";

        // fifth question
        document.getElementById('question5').innerHTML = "Q5. The toggle() method in jQuery is used to -";
        document.getElementById('lblq5choice1').innerHTML = "toggle between the hide() and show() methods";
        document.getElementById('lblq5choice2').innerHTML = "toggle between the fadeIn() and fadeOut() methods";
        document.getElementById('lblq5choice3').innerHTML = "toggle between the slideUp() and slideDown() methods";
        document.getElementById('lblq5choice4').innerHTML = "None of the above";
    
        // sixth question
        document.getElementById('question6').innerHTML = "Q6. If the names of variables are the same, then which of the following type of variable takes precedence?";
        document.getElementById('lblq6choice1').innerHTML = "local variable";
        document.getElementById('lblq6choice2').innerHTML = "global variable";
        document.getElementById('lblq6choice3').innerHTML = "both (a) & (b)";
        document.getElementById('lblq6choice4').innerHTML = "None of the above";
    
        //seventh question
        document.getElementById('question7').innerHTML = "Q7. Which of the following jQuery method is used to replace all selected elements with new HTML elements?";
        document.getElementById('lblq7choice1').innerHTML = "jQuery replaceWith() method";
        document.getElementById('lblq7choice2').innerHTML = "jQuery replaceAll() method";
        document.getElementById('lblq7choice3').innerHTML = "jQuery load() method";
        document.getElementById('lblq7choice4').innerHTML = "jQuery delegate() method";

        //Eighth question
        document.getElementById('question8').innerHTML = "Q8. Which method is used to attach one or more event handlers for the selected elements?";
        document.getElementById('lblq8choice1').innerHTML = "at()";
        document.getElementById('lblq8choice2').innerHTML = "atelements()";
        document.getElementById('lblq8choice3').innerHTML = "on()";
        document.getElementById('lblq8choice4').innerHTML = "focuson()";

        //Ninth question
        document.getElementById('question9').innerHTML = "Q9. Which is the correct syntax to insert content at the end of the p elements?";
        document.getElementById('lblq9choice1').innerHTML = `$("#p").append("Text to be added");`;
        document.getElementById('lblq9choice2').innerHTML = `$("p").before("Text to be added");`;
        document.getElementById('lblq9choice3').innerHTML = `$("p").append("Text to be added");`;
        document.getElementById('lblq9choice4').innerHTML = `$("p").prepend("Text to be added");`;

        //Tenth question
        document.getElementById('question10').innerHTML = "10. Which is the correct syntax to insert content after the div elements?";
        document.getElementById('lblq10choice1').innerHTML = `$("div").after("Text to be added");`;
        document.getElementById('lblq10choice2').innerHTML = `$("div").postpend("Text to be added");`;
        document.getElementById('lblq10choice3').innerHTML = `$("div").addafter("Text to be added");`;
        document.getElementById('lblq10choice4').innerHTML = `$("#div").after("Text to be added");`;
    }
}

// Ajax quiz
function ajaxquiz()
{
    var ajax = document.getElementById('languages');
    if(ajax.selectedIndex == 8)
    {
        // first question
        document.getElementById('question1').innerHTML = "Q1. Ajax stands for ______.";
        document.getElementById('lblq1choice1').innerHTML = "Asynchronous JavaScript and XML";
        document.getElementById('lblq1choice2').innerHTML = "Asynchronous JSON and XML";
        document.getElementById('lblq1choice3').innerHTML = "Asynchronous Java and XML";
        document.getElementById('lblq1choice4').innerHTML = "Asynchronous JavaScript and XMLHttpRequest";

        // second question
        document.getElementById('question2').innerHTML = "Q2. Which of the following is an example of an AJAX framework?";
        document.getElementById('lblq2choice1').innerHTML = "React";
        document.getElementById('lblq2choice2').innerHTML = "Vue.js";
        document.getElementById('lblq2choice3').innerHTML = "jQuery";
        document.getElementById('lblq2choice4').innerHTML = "Angular";

        // third question
        document.getElementById('question3').innerHTML = "Q3. Ajax technologies include ______.";
        document.getElementById('lblq3choice1').innerHTML = "HTML/XHTML and CSS";
        document.getElementById('lblq3choice2').innerHTML = "XML or JSON";
        document.getElementById('lblq3choice3').innerHTML = "JavaScript";
        document.getElementById('lblq3choice4').innerHTML = "All of the above"; 

        // fourth question
        document.getElementById('question4').innerHTML = "Q4. AJAX allows web page to dynamically ";
        document.getElementById('lblq4choice1').innerHTML = "Change content";
        document.getElementById('lblq4choice2').innerHTML = "Reload at times";
        document.getElementById('lblq4choice3').innerHTML = "Control other pages";
        document.getElementById('lblq4choice4').innerHTML = "Connect to other addresses";

        // fifth question
        document.getElementById('question5').innerHTML = "Q5. What is the advantage of using AJAX in web development?";
        document.getElementById('lblq5choice1').innerHTML = "It reduces server load and network traffic";
        document.getElementById('lblq5choice2').innerHTML = "It simplifies the development process";
        document.getElementById('lblq5choice3').innerHTML = "It improves security";
        document.getElementById('lblq5choice4').innerHTML = "It enhances the user interface";
    
        // sixth question
        document.getElementById('question6').innerHTML = "Q6. Which are the two properties to hold the status of XMLHttpRequest?";
        document.getElementById('lblq6choice1').innerHTML = "status and statusText";
        document.getElementById('lblq6choice2').innerHTML = "statusNum and statusText";
        document.getElementById('lblq6choice3').innerHTML = "statusId and statusText";
        document.getElementById('lblq6choice4').innerHTML = "None of the above";
    
        //seventh question
        document.getElementById('question7').innerHTML = "Q7.  Which method returns the specific header information?";
        document.getElementById('lblq7choice1').innerHTML = "getResponseHeader()";
        document.getElementById('lblq7choice2').innerHTML = "getSpecifcHeader()";
        document.getElementById('lblq7choice3').innerHTML = "getHeaderOnly()";
        document.getElementById('lblq7choice4').innerHTML = "getHeaderInfo()";

        //Eighth question
        document.getElementById('question8').innerHTML = "Q8. Which is the correct syntax to add HTTP headers to the request?";
        document.getElementById('lblq8choice1').innerHTML = "setRequestHeader(value, header)";
        document.getElementById('lblq8choice2').innerHTML = "setAllRequestHeader(value, header)";
        document.getElementById('lblq8choice3').innerHTML = "setRequestHeader(header, value)";
        document.getElementById('lblq8choice4').innerHTML = "setAllRequestHeader(header, value)";

        //Ninth question
        document.getElementById('question9').innerHTML = "Q9. Which are the two major features of AJAX?";
        document.getElementById('lblq9choice1').innerHTML = "Make requests to the server without reloading the page";
        document.getElementById('lblq9choice2').innerHTML = "Receive and work with data from the server";
        document.getElementById('lblq9choice3').innerHTML = "Make requests to the server with reloading the page";
        document.getElementById('lblq9choice4').innerHTML = "Only receive the data from the server";

        //Tenth question
        document.getElementById('question10').innerHTML = "10. Which of the following is a benefit of using AJAX for form submissions?";
        document.getElementById('lblq10choice1').innerHTML = "Improved security";
        document.getElementById('lblq10choice2').innerHTML = "Improved performance";
        document.getElementById('lblq10choice3').innerHTML = "Improved user experience";
        document.getElementById('lblq10choice4').innerHTML = "All of the above";
    }
}

//reactjs quiz
function reactjs()
{
    var reactjs = document.getElementById('languages');
    if(reactjs.selectedIndex == 9)
    {
        // first question
        document.getElementById('question1').innerHTML = "Q1. React is a ____.";
        document.getElementById('lblq1choice1').innerHTML = "Web development Framework";
        document.getElementById('lblq1choice2').innerHTML = "JavaScript Library";
        document.getElementById('lblq1choice3').innerHTML = "jQuery";
        document.getElementById('lblq1choice4').innerHTML = "Web Server";

        // second question
        document.getElementById('question2').innerHTML = "Q2. Which ReactJS command is used to create a new application?";
        document.getElementById('lblq2choice1').innerHTML = "create-react-app";
        document.getElementById('lblq2choice2').innerHTML = "new-react-app";
        document.getElementById('lblq2choice3').innerHTML = "create-new-reactapp";
        document.getElementById('lblq2choice4').innerHTML = "react-app";

        // third question
        document.getElementById('question3').innerHTML = "Q3. Which method is used to generate lists?";
        document.getElementById('lblq3choice1').innerHTML = "map()";
        document.getElementById('lblq3choice2').innerHTML = "generate()";
        document.getElementById('lblq3choice3').innerHTML = "new()";
        document.getElementById('lblq3choice4').innerHTML = "maps()"; 

        // fourth question
        document.getElementById('question4').innerHTML = "Q4. What is the default port where webpack-server runs?";
        document.getElementById('lblq4choice1').innerHTML = "443";
        document.getElementById('lblq4choice2').innerHTML = "3030";
        document.getElementById('lblq4choice3').innerHTML = "3306";
        document.getElementById('lblq4choice4').innerHTML = "8080";

        // fifth question
        document.getElementById('question5').innerHTML = "Q5. Which statement is required to define a class component?";
        document.getElementById('lblq5choice1').innerHTML = "extends React.Components";
        document.getElementById('lblq5choice2').innerHTML = "imports React.Components";
        document.getElementById('lblq5choice3').innerHTML = "extends React.Component";
        document.getElementById('lblq5choice4').innerHTML = "imports React.Component";
    
        // sixth question
        document.getElementById('question6').innerHTML = "Q6. In ReactJS, what is State?";
        document.getElementById('lblq6choice1').innerHTML = "It's a temporary storage of the elements";
        document.getElementById('lblq6choice2').innerHTML = "It's a state of the execution of the ReactJS application";
        document.getElementById('lblq6choice3').innerHTML = "It's an internal storage of the components";
        document.getElementById('lblq6choice4').innerHTML = "All of the above";
    
        //seventh question
        document.getElementById('question7').innerHTML = "Q7. What are the two ways to handle data in React?";
        document.getElementById('lblq7choice1').innerHTML = "State & Props";
        document.getElementById('lblq7choice2').innerHTML = "Services & Components";
        document.getElementById('lblq7choice3').innerHTML = "State & Services";
        document.getElementById('lblq7choice4').innerHTML = "State & Component";

        //Eighth question
        document.getElementById('question8').innerHTML = "Q8. In which directory React Components are saved?";
        document.getElementById('lblq8choice1').innerHTML = "Inside js/components/";
        document.getElementById('lblq8choice2').innerHTML = "Inside vendor/components/";
        document.getElementById('lblq8choice3').innerHTML = "Inside vendor/components/";
        document.getElementById('lblq8choice4').innerHTML = "Inside vendor/";

        //Ninth question
        document.getElementById('question9').innerHTML = "Q9. Which of the following statement is true for controlled components in React.js?";
        document.getElementById('lblq9choice1').innerHTML = "The source of truth is DOM";
        document.getElementById('lblq9choice2').innerHTML = "The source of truth can be anything";
        document.getElementById('lblq9choice3').innerHTML = "The source of truth is a component state";
        document.getElementById('lblq9choice4').innerHTML = "None of the above";

        //Tenth question
        document.getElementById('question10').innerHTML = "10. What are the limitations of ReactJS?";
        document.getElementById('lblq10choice1').innerHTML = "React is only for view layer of the app so we still need the help of other technologies to get a complete tooling set for development";
        document.getElementById('lblq10choice2').innerHTML = "React is using inline templating and JSX. This can seem awkward to some developers";
        document.getElementById('lblq10choice3').innerHTML = "The library of react is too large";
        document.getElementById('lblq10choice4').innerHTML = "All of these";
    }
}

//reactnative quiz
function reactnative()
{
    var reactnative = document.getElementById('languages');
    if(reactnative.selectedIndex == 10)
    {
        // first question
        document.getElementById('question1').innerHTML = `Q1. Which of these React native components will be used to display the name="React Native Tutorial"?`;
        document.getElementById('lblq1choice1').innerHTML = "View";
        document.getElementById('lblq1choice2').innerHTML = "Text";
        document.getElementById('lblq1choice3').innerHTML = "span";
        document.getElementById('lblq1choice4').innerHTML = "p";

        // second question
        document.getElementById('question2').innerHTML = "Q2. Which of the following is the correct way to store data in a local device?";
        document.getElementById('lblq2choice1').innerHTML = "Asyncstorage";
        document.getElementById('lblq2choice2').innerHTML = "Localstorage";
        document.getElementById('lblq2choice3').innerHTML = "Sessionstorage";
        document.getElementById('lblq2choice4').innerHTML = "RNStorage";

        // third question
        document.getElementById('question3').innerHTML = "Q3. Which of the following components is used to make an input field in React Native?";
        document.getElementById('lblq3choice1').innerHTML = "input";
        document.getElementById('lblq3choice2').innerHTML = "TextInput";
        document.getElementById('lblq3choice3').innerHTML = "EditInput";
        document.getElementById('lblq3choice4').innerHTML = "InputText"; 

        // fourth question
        document.getElementById('question4').innerHTML = "Q4. Which is the correct place to make an api call on screen load in a class component?";
        document.getElementById('lblq4choice1').innerHTML = "Constructor";
        document.getElementById('lblq4choice2').innerHTML = "Componentdidmount";
        document.getElementById('lblq4choice3').innerHTML = "Componentdidupdate";
        document.getElementById('lblq4choice4').innerHTML = "Componentwillmount";

        // fifth question
        document.getElementById('question5').innerHTML = "Q5. Which Javascript function is used to loop through an array?";
        document.getElementById('lblq5choice1').innerHTML = "Map";
        document.getElementById('lblq5choice2').innerHTML = "Object.keys";
        document.getElementById('lblq5choice3').innerHTML = "Render";
        document.getElementById('lblq5choice4').innerHTML = "Var";
    
        // sixth question
        document.getElementById('question6').innerHTML = "Q6. What is the entry point of React native apps?";
        document.getElementById('lblq6choice1').innerHTML = "Index.js";
        document.getElementById('lblq6choice2').innerHTML = "App.js";
        document.getElementById('lblq6choice3').innerHTML = "App.json";
        document.getElementById('lblq6choice4').innerHTML = "Config.json";
    
        //seventh question
        document.getElementById('question7').innerHTML = "Q7. Which property is used to open the screen on an app open in React Navigation?";
        document.getElementById('lblq7choice1').innerHTML = "initialRouteName";
        document.getElementById('lblq7choice2').innerHTML = "onAppopen";
        document.getElementById('lblq7choice3').innerHTML = "startScreen";
        document.getElementById('lblq7choice4').innerHTML = "startApp";

        //Eighth question
        document.getElementById('question8').innerHTML = "Q8.  How do you style your React Native component?";
        document.getElementById('lblq8choice1').innerHTML = "Stylesheet.create";
        document.getElementById('lblq8choice2').innerHTML = "Stylesheet.css";
        document.getElementById('lblq8choice3').innerHTML = "Safeareaview";
        document.getElementById('lblq8choice4').innerHTML = "Flatlist";

        //Ninth question
        document.getElementById('question9').innerHTML = "Q9. Which of the following is not the correct way to make an api request?";
        document.getElementById('lblq9choice1').innerHTML = "Axios.get(“url”)";
        document.getElementById('lblq9choice2').innerHTML = "fetch(“url”)";
        document.getElementById('lblq9choice3').innerHTML = "import(“url”)";
        document.getElementById('lblq9choice4').innerHTML = "XMLHttpRequest";

        //Tenth question
        document.getElementById('question10').innerHTML = "10. is the correct command to install a react native project?";
        document.getElementById('lblq10choice1').innerHTML = "npx create-react-app appname";
        document.getElementById('lblq10choice2').innerHTML = "npx create-react-app init appname";
        document.getElementById('lblq10choice3').innerHTML = "Npx react-native init appname";
        document.getElementById('lblq10choice4').innerHTML = "Npx react-native app init";
    }
}

//Angular quiz
function angular()
{
    var angular = document.getElementById('languages');
    if(angular.selectedIndex == 11)
    {
        // first question
        document.getElementById('question1').innerHTML = `Q1. Which of the following statement is correct for AngularJS?"?`;
        document.getElementById('lblq1choice1').innerHTML = "AngularJS is an HTML framework";
        document.getElementById('lblq1choice2').innerHTML = "AngularJS is a Java framework";
        document.getElementById('lblq1choice3').innerHTML = "AngularJS is a JavaScript framework";
        document.getElementById('lblq1choice4').innerHTML = "AngularJS is a SQL framework";

        // second question
        document.getElementById('question2').innerHTML = "Q2. On which of the Architectural pattern AngularJS is based?";
        document.getElementById('lblq2choice1').innerHTML = "Observer Pattern";
        document.getElementById('lblq2choice2').innerHTML = "Decorator pattern";
        document.getElementById('lblq2choice3').innerHTML = "MVC Architecture pattern";
        document.getElementById('lblq2choice4').innerHTML = "MVVM Architectural pattern";

        // third question
        document.getElementById('question3').innerHTML = "Q3. Who maintained AngularJS?";
        document.getElementById('lblq3choice1').innerHTML = "Google";
        document.getElementById('lblq3choice2').innerHTML = "A community of individuals and corporations";
        document.getElementById('lblq3choice3').innerHTML = "Oracle";
        document.getElementById('lblq3choice4').innerHTML = "Both A. and B."; 

        // fourth question
        document.getElementById('question4').innerHTML = "Q4. Which of the following syntax is used to create a module in AngularJS?";
        document.getElementById('lblq4choice1').innerHTML = "var myModule= angular.module();";
        document.getElementById('lblq4choice2').innerHTML = "var myModule= new Module();";
        document.getElementById('lblq4choice3').innerHTML = `module("app", []);`;
        document.getElementById('lblq4choice4').innerHTML = "None of the above";

        // fifth question
        document.getElementById('question5').innerHTML = "Q5. Which of the following is used to share data between controller and view in AngularJS?";
        document.getElementById('lblq5choice1').innerHTML = "using Model";
        document.getElementById('lblq5choice2').innerHTML = "using services";
        document.getElementById('lblq5choice3').innerHTML = "using factory";
        document.getElementById('lblq5choice4').innerHTML = "using $scope";
    
        // sixth question
        document.getElementById('question6').innerHTML = "Q6. Which of the following types of the component can be used to create a custom directive?";
        document.getElementById('lblq6choice1').innerHTML = "Element directives";
        document.getElementById('lblq6choice2').innerHTML = "Attribute";
        document.getElementById('lblq6choice3').innerHTML = "CSS";
        document.getElementById('lblq6choice4').innerHTML = "All of the above.";
    
        //seventh question
        document.getElementById('question7').innerHTML = "Q7. Which of the following statement is true in the case of a controller in MVC?";
        document.getElementById('lblq7choice1').innerHTML = "A controller is a software code that controls the interactions between the Model and View.";
        document.getElementById('lblq7choice2').innerHTML = "A controller is a software code that stores the data.";
        document.getElementById('lblq7choice3').innerHTML = "startScreenA controller is a software code that renders the user interface.";
        document.getElementById('lblq7choice4').innerHTML = "All of the above.";

        //Eighth question
        document.getElementById('question8').innerHTML = "Q8. Which of the following syntax is correct for applying multiple filters in AngularJS?";
        document.getElementById('lblq8choice1').innerHTML = "{{ expression | filter1 | filter2 | ... }}";
        document.getElementById('lblq8choice2').innerHTML = "{{ expression | {filter1} | {filter2} | ... }}";
        document.getElementById('lblq8choice3').innerHTML = "{{ expression - {filter1} - {filter2} - ... }}";
        document.getElementById('lblq8choice4').innerHTML = "{{ {filter1} | {filter2} | ...-expression}}";

        //Ninth question
        document.getElementById('question9').innerHTML = "Q9. Filters can be added to expressions by using the ______, followed by a filter.";
        document.getElementById('lblq9choice1').innerHTML = "comma character (,)";
        document.getElementById('lblq9choice2').innerHTML = "Colon character (:)";
        document.getElementById('lblq9choice3').innerHTML = "Hyphen character (-)";
        document.getElementById('lblq9choice4').innerHTML = "pipe character (|)";

        //Tenth question
        document.getElementById('question10').innerHTML = "10. Which of the following can be used as a prefix for Directive?";
        document.getElementById('lblq10choice1').innerHTML = "data-";
        document.getElementById('lblq10choice2').innerHTML = "ng-";
        document.getElementById('lblq10choice3').innerHTML = "Both A and B";
        document.getElementById('lblq10choice4').innerHTML = "None of the above";
    }
}

//Laravel quiz
function laravel()
{
    var laravel = document.getElementById('languages');
    if(laravel.selectedIndex == 12)
    {
        // first question
        document.getElementById('question1').innerHTML = "Q1. What is Laravel?";
        document.getElementById('lblq1choice1').innerHTML = "Programming language";
        document.getElementById('lblq1choice2').innerHTML = "PHP framework";
        document.getElementById('lblq1choice3').innerHTML = "Code generator";
        document.getElementById('lblq1choice4').innerHTML = "None of the above";

        // second question
        document.getElementById('question2').innerHTML = "Q2. Who developed Laravel?";
        document.getElementById('lblq2choice1').innerHTML = "James Gosling";
        document.getElementById('lblq2choice2').innerHTML = "Rasmus Lerdorf";
        document.getElementById('lblq2choice3').innerHTML = "Taylor Otwell";
        document.getElementById('lblq2choice4').innerHTML = "Guido van Rossum";

        // third question
        document.getElementById('question3').innerHTML = "Q3. Which command is used to start laravel server?";
        document.getElementById('lblq3choice1').innerHTML = "php artisan project_name";
        document.getElementById('lblq3choice2').innerHTML = "artisan start-server";
        document.getElementById('lblq3choice3').innerHTML = "php artisan serve";
        document.getElementById('lblq3choice4').innerHTML = "php artisan start php"; 

        // fourth question
        document.getElementById('question4').innerHTML = "Q4. How to check current laravel version install your system?";
        document.getElementById('lblq4choice1').innerHTML = "php artisan check –version";
        document.getElementById('lblq4choice2').innerHTML = "php artisan make –version";
        document.getElementById('lblq4choice3').innerHTML = "php artisan –version";
        document.getElementById('lblq4choice4').innerHTML = "None of the above";

        // fifth question
        document.getElementById('question5').innerHTML = "Q5. What is the command to create a new Laravel project?";
        document.getElementById('lblq5choice1').innerHTML = "laravel new";
        document.getElementById('lblq5choice2').innerHTML = " create-laravel";
        document.getElementById('lblq5choice3').innerHTML = "new-project";
        document.getElementById('lblq5choice4').innerHTML = "laravel create";
    
        // sixth question
        document.getElementById('question6').innerHTML = "Q6. How to check current laravel version install your system?";
        document.getElementById('lblq6choice1').innerHTML = "php artisan check –version";
        document.getElementById('lblq6choice2').innerHTML = "php artisan make –version";
        document.getElementById('lblq6choice3').innerHTML = "php artisan –version";
        document.getElementById('lblq6choice4').innerHTML = "none of the above";
    
        //seventh question
        document.getElementById('question7').innerHTML = "Q7. Where are all the Laravel Models stored at ?";
        document.getElementById('lblq7choice1').innerHTML = "Inside Laravel database";
        document.getElementById('lblq7choice2').innerHTML = "Within a server";
        document.getElementById('lblq7choice3').innerHTML = "Main app directory";
        document.getElementById('lblq7choice4').innerHTML = "None of the above";

        //Eighth question
        document.getElementById('question8').innerHTML = "Q8. What type of way does Laravel use to get data from a database ?";
        document.getElementById('lblq8choice1').innerHTML = "Eloquent ORM and Query Builder";
        document.getElementById('lblq8choice2').innerHTML = "Eloquent ORM";
        document.getElementById('lblq8choice3').innerHTML = "Query Builder";
        document.getElementById('lblq8choice4').innerHTML = "None of the above";

        //Ninth question
        document.getElementById('question9').innerHTML = "Q9. Which one of the following command is used to create middleware in Laravel?";
        document.getElementById('lblq9choice1').innerHTML = "php artisan make: middleware";
        document.getElementById('lblq9choice2').innerHTML = "php arti make: middleware";
        document.getElementById('lblq9choice3').innerHTML = "php artisan: middleware";
        document.getElementById('lblq9choice4').innerHTML = "none of the above";

        //Tenth question
        document.getElementById('question10').innerHTML = "10. How to get current action name in Laravel?";
        document.getElementById('lblq10choice1').innerHTML = "request()->DB->getActionMethod()";
        document.getElementById('lblq10choice2').innerHTML = "request()->route()->getActionMethod()";
        document.getElementById('lblq10choice3').innerHTML = "request()->getActionMethod()";
        document.getElementById('lblq10choice4').innerHTML = "none of the above";
    }
}

//PHP quiz
function php()
{
    var php = document.getElementById('languages');
    if(php.selectedIndex == 13)
    {
        // first question
        document.getElementById('question1').innerHTML = "Q1. PHP is an acronym for ____.";
        document.getElementById('lblq1choice1').innerHTML = "Prefix Hypertext Preprocessor";
        document.getElementById('lblq1choice2').innerHTML = "Prototype Hypertext Preprocessor";
        document.getElementById('lblq1choice3').innerHTML = "Hypertext Preprocessor";
        document.getElementById('lblq1choice4').innerHTML = "Hypertext Preprocessor";

        // second question
        document.getElementById('question2').innerHTML = "Q2. Who developed PHP?";
        document.getElementById('lblq2choice1').innerHTML = "Guido van Rossum";
        document.getElementById('lblq2choice2').innerHTML = "Rasmus Lerdorf";
        document.getElementById('lblq2choice3').innerHTML = "Jesse James Garrett";
        document.getElementById('lblq2choice4').innerHTML = "Douglas Crockford";

        // third question
        document.getElementById('question3').innerHTML = "Q3. Which sign is used to declare variables in PHP?";
        document.getElementById('lblq3choice1').innerHTML = "@";
        document.getElementById('lblq3choice2').innerHTML = "&";
        document.getElementById('lblq3choice3').innerHTML = "$";
        document.getElementById('lblq3choice4').innerHTML = "_"; 

        // fourth question
        document.getElementById('question4').innerHTML = "Q4. There are two variables a, b which declared in global scope, which is the correct PHP statement to access them within a function?";
        document.getElementById('lblq4choice1').innerHTML = "global $a, $b;";
        document.getElementById('lblq4choice2').innerHTML = "global $a $b;";
        document.getElementById('lblq4choice3').innerHTML = "global ($a, $b);";
        document.getElementById('lblq4choice4').innerHTML = "php_global $a, $b;";

        // fifth question
        document.getElementById('question5').innerHTML = "Q5. Which is/are the function(s) to check if a numeric value is finite or infinite?";
        document.getElementById('lblq5choice1').innerHTML = "is_finite()";
        document.getElementById('lblq5choice2').innerHTML = "is_infinite()";
        document.getElementById('lblq5choice3').innerHTML = "is_inf()";
        document.getElementById('lblq5choice4').innerHTML = "Both A and B";
    
        // sixth question
        document.getElementById('question6').innerHTML = "Q6. Which is the correct syntax to cast float to integer?";
        document.getElementById('lblq6choice1').innerHTML = "(int) float_variable";
        document.getElementById('lblq6choice2').innerHTML = "int (float_variable)";
        document.getElementById('lblq6choice3').innerHTML = "(int) (float_variable)";
        document.getElementById('lblq6choice4').innerHTML = "All of the above";
    
        //seventh question
        document.getElementById('question7').innerHTML = "Q7. What is name of PHP "===" operator?";
        document.getElementById('lblq7choice1').innerHTML = "Equal";
        document.getElementById('lblq7choice2').innerHTML = "Safe Equal";
        document.getElementById('lblq7choice3').innerHTML = "Identity";
        document.getElementById('lblq7choice4').innerHTML = "None of the above";

        //Eighth question
        document.getElementById('question8').innerHTML = "Q8. Which is the correct syntax of defining a default argument value in PHP?";
        document.getElementById('lblq8choice1').innerHTML = "function function_name(type $argument_name : value) { /* function body*/ }";
        document.getElementById('lblq8choice2').innerHTML = "function function_name(type $argument_name , value) { /* function body*/ }";
        document.getElementById('lblq8choice3').innerHTML = "function function_name(type $argument_name = value) { /* function body*/ }";
        document.getElementById('lblq8choice4').innerHTML = "All of the above";

        //Ninth question
        document.getElementById('question9').innerHTML = "Q9. What is the difference between Indexed array and Associative array in PHP?";
        document.getElementById('lblq9choice1').innerHTML = "Index array has numeric index while associative array has named keys";
        document.getElementById('lblq9choice2').innerHTML = "Index array has numeric index while associative array has named keys and numeric index both";
        document.getElementById('lblq9choice3').innerHTML = "Index array is one-dimensional array with numeric index while associative array is two-dimensional array with numeric index";
        document.getElementById('lblq9choice4').innerHTML = "Index array has numeric index while associative array has one or more arrays";

        //Tenth question
        document.getElementById('question10').innerHTML = "10. What is the use of PHP $_SERVER variable?";
        document.getElementById('lblq10choice1').innerHTML = "To update the content on the server";
        document.getElementById('lblq10choice2').innerHTML = "To access the information about headers, paths, and script locations";
        document.getElementById('lblq10choice3').innerHTML = "To access and update the database records on the server";
        document.getElementById('lblq10choice4').innerHTML = "All of the above";
    }
}

//Flutter quiz
function flutter()
{
    var flutter = document.getElementById('languages');
    if(flutter.selectedIndex == 14)
    {
        // first question
        document.getElementById('question1').innerHTML = "Q1. What is Flutter?";
        document.getElementById('lblq1choice1').innerHTML = "Flutter is an open-source backend development framework";
        document.getElementById('lblq1choice2').innerHTML = "Flutter is an open-source UI toolkit";
        document.getElementById('lblq1choice3').innerHTML = "Flutter is an open-source programming language for cross-platform applications";
        document.getElementById('lblq1choice4').innerHTML = "Flutters is a DBMS toolkit";

        // second question
        document.getElementById('question2').innerHTML = "Q2. Which programming language is used to build Flutter applications?";
        document.getElementById('lblq2choice1').innerHTML = "Kotlin";
        document.getElementById('lblq2choice2').innerHTML = "Dart";
        document.getElementById('lblq2choice3').innerHTML = "Java";
        document.getElementById('lblq2choice4').innerHTML = "Go";

        // third question
        document.getElementById('question3').innerHTML = "Q3. What are some key advantages of Flutter over alternate frameworks?";
        document.getElementById('lblq3choice1').innerHTML = "Rapid cross-platform application development and debugging tools";
        document.getElementById('lblq3choice2').innerHTML = "Future-proofed technologies and UI resources";
        document.getElementById('lblq3choice3').innerHTML = "Strong supporting tools for application development and launch";
        document.getElementById('lblq3choice4').innerHTML = "All of the above"; 

        // fourth question
        document.getElementById('question4').innerHTML = "Q4. What is the purpose of the runApp() function in Flutter?";
        document.getElementById('lblq4choice1').innerHTML = "To start the Flutter application";
        document.getElementById('lblq4choice2').innerHTML = "To define the layout of the user interface";
        document.getElementById('lblq4choice3').innerHTML = "To handle user input";
        document.getElementById('lblq4choice4').innerHTML = "To manage the state of the application";

        // fifth question
        document.getElementById('question5').innerHTML = "Q5. What is the purpose of the Navigator widget in Flutter?";
        document.getElementById('lblq5choice1').innerHTML = "To create a new widget";
        document.getElementById('lblq5choice2').innerHTML = "To manage the state of the application";
        document.getElementById('lblq5choice3').innerHTML = "To handle user input";
        document.getElementById('lblq5choice4').innerHTML = "To navigate between different screens in the app";
    
        // sixth question
        document.getElementById('question6').innerHTML = "Q6. What is the purpose of the ListView widget in Flutter?";
        document.getElementById('lblq6choice1').innerHTML = "To display a collection of widgets in a scrollable list";
        document.getElementById('lblq6choice2').innerHTML = "To create a new widget";
        document.getElementById('lblq6choice3').innerHTML = "To provide a set of material design widgets";
        document.getElementById('lblq6choice4').innerHTML = "To provide a flexible container for layout and styling";
    
        //seventh question
        document.getElementById('question7').innerHTML = "Q7. What is the purpose of the Scaffold widget in Flutter?";
        document.getElementById('lblq7choice1').innerHTML = "To create a new widget";
        document.getElementById('lblq7choice2').innerHTML = "To provide a set of material design widgets";
        document.getElementById('lblq7choice3').innerHTML = "To provide a layout for the application’s pages";
        document.getElementById('lblq7choice4').innerHTML = "To manage the state of the application";

        //Eighth question
        document.getElementById('question8').innerHTML = "Q8. Choose the best editors for Flutter app development?";
        document.getElementById('lblq8choice1').innerHTML = "VS Code";
        document.getElementById('lblq8choice2').innerHTML = "Sublime Text";
        document.getElementById('lblq8choice3').innerHTML = "Android Studio";
        document.getElementById('lblq8choice4').innerHTML = "All of the above";

        //Ninth question
        document.getElementById('question9').innerHTML = "Q9. Which widget is used to create a switch in Flutter?";
        document.getElementById('lblq9choice1').innerHTML = "ToggleSwitch";
        document.getElementById('lblq9choice2').innerHTML = "Switch";
        document.getElementById('lblq9choice3').innerHTML = "OnOffSwitch";
        document.getElementById('lblq9choice4').innerHTML = "All of the above";

        //Tenth question
        document.getElementById('question10').innerHTML = "10. Which widget is used to create a tab bar in Flutter?";
        document.getElementById('lblq10choice1').innerHTML = "TabBarWidget";
        document.getElementById('lblq10choice2').innerHTML = "TabLayout";
        document.getElementById('lblq10choice3').innerHTML = "TabBar";
        document.getElementById('lblq10choice4').innerHTML = "NavigationTabBar";
    }
}

//MEAN Stack quiz
function meanstack()
{
    var mean = document.getElementById('languages');
    if(mean.selectedIndex == 15)
    {
        // first question
        document.getElementById('question1').innerHTML = "Q1. Mean stack is a ____.";
        document.getElementById('lblq1choice1').innerHTML = "Angular-based framework";
        document.getElementById('lblq1choice2').innerHTML = "JavaScript-based framework";
        document.getElementById('lblq1choice3').innerHTML = "Python-based framework";
        document.getElementById('lblq1choice4').innerHTML = "PHP-based framework";

        // second question
        document.getElementById('question2').innerHTML = "Q2. Which of the following contains strong models for URL routing (mapping an incoming URL to a server function), and manages HTTP requests and responses?";
        document.getElementById('lblq2choice1').innerHTML = "MongoDB";
        document.getElementById('lblq2choice2').innerHTML = "Express";
        document.getElementById('lblq2choice3').innerHTML = "Angular";
        document.getElementById('lblq2choice4').innerHTML = "Node";

        // third question
        document.getElementById('question3').innerHTML = "Q3. The major front-end AngularJS functionality for the application is in the ____ folder.";
        document.getElementById('lblq3choice1').innerHTML = "App";
        document.getElementById('lblq3choice2').innerHTML = "Config";
        document.getElementById('lblq3choice3').innerHTML = "Modules";
        document.getElementById('lblq3choice4').innerHTML = "Public"; 

        // fourth question
        document.getElementById('question4').innerHTML = "Q4. Which of the following is used to make HTTP requests to a server?";
        document.getElementById('lblq4choice1').innerHTML = "$http";
        document.getElementById('lblq4choice2').innerHTML = "$ftp";
        document.getElementById('lblq4choice3').innerHTML = "$url";
        document.getElementById('lblq4choice4').innerHTML = "$web";

        // fifth question
        document.getElementById('question5').innerHTML = "Q5. Mean stack is used for ____.";
        document.getElementById('lblq5choice1').innerHTML = "Deploying web applications";
        document.getElementById('lblq5choice2').innerHTML = "Developing ORM-based applications";
        document.getElementById('lblq5choice3').innerHTML = "Developing web applications";
        document.getElementById('lblq5choice4').innerHTML = "None of the above";
    
        // sixth question
        document.getElementById('question6').innerHTML = "Q6. You save all of your program's variable runtime configuration settings and a collection of application utility functions in which of the following folder?";
        document.getElementById('lblq6choice1').innerHTML = "App";
        document.getElementById('lblq6choice2').innerHTML = "Config";
        document.getElementById('lblq6choice3').innerHTML = "Modules";
        document.getElementById('lblq6choice4').innerHTML = "Public";
    
        //seventh question
        document.getElementById('question7').innerHTML = "Q7. How many technologies make up the layers of the MEAN stack?";
        document.getElementById('lblq7choice1').innerHTML = "7";
        document.getElementById('lblq7choice2').innerHTML = "6";
        document.getElementById('lblq7choice3').innerHTML = "5";
        document.getElementById('lblq7choice4').innerHTML = "4";

        //Eighth question
        document.getElementById('question8').innerHTML = "Q8.  ____ is at the very top of the MEAN stack.";
        document.getElementById('lblq8choice1').innerHTML = "MongoDB";
        document.getElementById('lblq8choice2').innerHTML = "Express";
        document.getElementById('lblq8choice3').innerHTML = "Angular";
        document.getElementById('lblq8choice4').innerHTML = "Node";

        //Ninth question
        document.getElementById('question9').innerHTML = "Q9. ____ is used to make variables and functions accessible from outside the module.";
        document.getElementById('lblq9choice1').innerHTML = "Include";
        document.getElementById('lblq9choice2').innerHTML = "Path";
        document.getElementById('lblq9choice3').innerHTML = "Require";
        document.getElementById('lblq9choice4').innerHTML = "Export";

        //Tenth question
        document.getElementById('question10').innerHTML = "10. Angular.js is written in ____.";
        document.getElementById('lblq10choice1').innerHTML = "C++";
        document.getElementById('lblq10choice2').innerHTML = "C";
        document.getElementById('lblq10choice3').innerHTML = "Java";
        document.getElementById('lblq10choice4').innerHTML = "JavaScript";
    }
}

// Tailwind CSS quiz
function tailwindcss()
{
    var tailwind = document.getElementById('languages');
    if(tailwind.selectedIndex == 16)
    {
        // first question
        document.getElementById('question1').innerHTML = "Q1. Why do we use Tailwind CSS?";
        document.getElementById('lblq1choice1').innerHTML = "Make the web pages dyanamic";
        document.getElementById('lblq1choice2').innerHTML = "Creates web pages interactive";
        document.getElementById('lblq1choice3').innerHTML = "Design and style web pages fast and Responsive.";
        document.getElementById('lblq1choice4').innerHTML = "None of the above";

        // second question
        document.getElementById('question2').innerHTML = "Q2. What is the value in px for one spacing unit in Tailwind CSS";
        document.getElementById('lblq2choice1').innerHTML = "4 px";
        document.getElementById('lblq2choice2').innerHTML = "5 px";
        document.getElementById('lblq2choice3').innerHTML = "10 px";
        document.getElementById('lblq2choice4').innerHTML = "8 px";

        // third question
        document.getElementById('question3').innerHTML = "Q3. What is the valid value for the screens key in Tailwind CSS";
        document.getElementById('lblq3choice1').innerHTML = "sm";
        document.getElementById('lblq3choice2').innerHTML = "md";
        document.getElementById('lblq3choice3').innerHTML = "lg";
        document.getElementById('lblq3choice4').innerHTML = "All of these"; 

        // fourth question
        document.getElementById('question4').innerHTML = "Q4. What is not a CSS preprocessor like Tailwind CSS";
        document.getElementById('lblq4choice1').innerHTML = "Sass";
        document.getElementById('lblq4choice2').innerHTML = "Less";
        document.getElementById('lblq4choice3').innerHTML = "Stylus";
        document.getElementById('lblq4choice4').innerHTML = "None of these";

        // fifth question
        document.getElementById('question5').innerHTML = "Q5. Who inherit the spacing scale in Tailwind CSS";
        document.getElementById('lblq5choice1').innerHTML = "padding";
        document.getElementById('lblq5choice2').innerHTML = "margin";
        document.getElementById('lblq5choice3').innerHTML = "width";
        document.getElementById('lblq5choice4').innerHTML = "All of these";
    
        // sixth question
        document.getElementById('question6').innerHTML = "Q6. What is the purpose of the `border-b-4 class in Tailwind CSS`";
        document.getElementById('lblq6choice1').innerHTML = "Adds a 4 pixel border to the bottom of the element";
        document.getElementById('lblq6choice2').innerHTML = "Sets the bottom margin to 4 pixels";
        document.getElementById('lblq6choice3').innerHTML = "Adds a 4 pixel padding to the bottom of the element";
        document.getElementById('lblq6choice4').innerHTML = "Styles the bottom border with a width of 4";
    
        //seventh question
        document.getElementById('question7').innerHTML = "Q7. What is the purpose of the transition-transform class in Tailwind CSS";
        document.getElementById('lblq7choice1').innerHTML = "Adds a transition effect to the transform property";
        document.getElementById('lblq7choice2').innerHTML = "Styles the text as a transitional element";
        document.getElementById('lblq7choice3').innerHTML = "Set the transition duration for transformations";
        document.getElementById('lblq7choice4').innerHTML = "Adds a shadow effect with a transition";

        //Eighth question
        document.getElementById('question8').innerHTML = "Q8. How can you apply a blur filter to an element in Tailwind CSS";
        document.getElementById('lblq8choice1').innerHTML = "filter-blur";
        document.getElementById('lblq8choice2').innerHTML = "blur-100";
        document.getElementById('lblq8choice3').innerHTML = "filter filter-blur-100";
        document.getElementById('lblq8choice4').innerHTML = "blur";

        //Ninth question
        document.getElementById('question9').innerHTML = "Q9. What does the `underline` class in Tailwind CSS do";
        document.getElementById('lblq9choice1').innerHTML = "Adds an underline to the text";
        document.getElementById('lblq9choice2').innerHTML = "Sets the text color to underline";
        document.getElementById('lblq9choice3').innerHTML = "Styles the text as an underline element";
        document.getElementById('lblq9choice4').innerHTML = "Adds a shadow effect to the text";

        //Tenth question
        document.getElementById('question10').innerHTML = "10. Which CSS property is used to create rounded corners on an element";
        document.getElementById('lblq10choice1').innerHTML = "border-radius";
        document.getElementById('lblq10choice2').innerHTML = "corner-radius";
        document.getElementById('lblq10choice3').innerHTML = "round-corner";
        document.getElementById('lblq10choice4').innerHTML = "border-style";

    }
}

// MERN stack quiz
function mernstack()
{
    var mern = document.getElementById('languages');
    if(mern.selectedIndex == 17)
    {
        // first question
        document.getElementById('question1').innerHTML = "Q1. What does the acronym `MERN` stand for in the context of web development?";
        document.getElementById('lblq1choice1').innerHTML = "MongoDB, Express, React, Node.js";
        document.getElementById('lblq1choice2').innerHTML = "MySQL, Express, React, Node.js";
        document.getElementById('lblq1choice3').innerHTML = "MongoDB, Express, Redux, Node.js";
        document.getElementById('lblq1choice4').innerHTML = "MySQL, Express, Redux, Node.js";

        // second question
        document.getElementById('question2').innerHTML = "Q2. Which technology in the MERN stack is used for front-end development?";
        document.getElementById('lblq2choice1').innerHTML = "MongoDB";
        document.getElementById('lblq2choice2').innerHTML = "Express";
        document.getElementById('lblq2choice3').innerHTML = "React";
        document.getElementById('lblq2choice4').innerHTML = "Node.js";

        // third question
        document.getElementById('question3').innerHTML = "Q3. Which technology in the MERN stack is used as a server-side framework?";
        document.getElementById('lblq3choice1').innerHTML = "MongoDB";
        document.getElementById('lblq3choice2').innerHTML = "Express";
        document.getElementById('lblq3choice3').innerHTML = "React";
        document.getElementById('lblq3choice4').innerHTML = "Node.js"; 

        // fourth question
        document.getElementById('question4').innerHTML = "Q4. Which of the following best describes Node.js in the MERN stack?";
        document.getElementById('lblq4choice1').innerHTML = "A front-end library for building user interfaces.";
        document.getElementById('lblq4choice2').innerHTML = "A back-end framework for handling server-side logic.";
        document.getElementById('lblq4choice3').innerHTML = "A database management system.";
        document.getElementById('lblq4choice4').innerHTML = "A styling framework for CSS.";

        // fifth question
        document.getElementById('question5').innerHTML = "Q5. Why might a company choose a MERN stack for their web application development?";
        document.getElementById('lblq5choice1').innerHTML = "It is the cheapest stack available.";
        document.getElementById('lblq5choice2').innerHTML = "It provides a comprehensive set of tools for both front-end and back-end development.";
        document.getElementById('lblq5choice3').innerHTML = "It is exclusively used for building mobile applications.";
        document.getElementById('lblq5choice4').innerHTML = "It requires less coding skills.";
    
        // sixth question
        document.getElementById('question6').innerHTML = "Q6. In a typical MERN stack application, what is the role of the package.json file?";
        document.getElementById('lblq6choice1').innerHTML = "It defines the structure of the MongoDB database.";
        document.getElementById('lblq6choice2').innerHTML = "It specifies the front-end components used in the application.";
        document.getElementById('lblq6choice3').innerHTML = "It lists the project dependencies and scripts for the Node.js application.";
        document.getElementById('lblq6choice4').innerHTML = "It configures the React application.";
    
        //seventh question
        document.getElementById('question7').innerHTML = "Q7. Which technology in the MERN stack is used to build APIs that communicate with the database?";
        document.getElementById('lblq7choice1').innerHTML = "MongoDB";
        document.getElementById('lblq7choice2').innerHTML = "Express";
        document.getElementById('lblq7choice3').innerHTML = "React";
        document.getElementById('lblq7choice4').innerHTML = "Node.js";

        //Eighth question
        document.getElementById('question8').innerHTML = "Q8. What is the primary purpose of Node.js in the MERN stack?";
        document.getElementById('lblq8choice1').innerHTML = "To serve as the front-end framework for building UI";
        document.getElementById('lblq8choice2').innerHTML = "To manage the database schema and structure";
        document.getElementById('lblq8choice3').innerHTML = "To handle server-side operations and provide a runtime environment for JavaScript";
        document.getElementById('lblq8choice4').innerHTML = "To style web pages using CSS";

        //Ninth question
        document.getElementById('question9').innerHTML = "Q9. Which of the following is NOT a technology used by a MERN Stack Developer?";
        document.getElementById('lblq9choice1').innerHTML = "MongoDB";
        document.getElementById('lblq9choice2').innerHTML = "Express";
        document.getElementById('lblq9choice3').innerHTML = "Angular";
        document.getElementById('lblq9choice4').innerHTML = "Node.js";

        //Tenth question
        document.getElementById('question10').innerHTML = "10. Which command is commonly used to install Node.js packages, including those for the MERN stack?";
        document.getElementById('lblq10choice1').innerHTML = "npm install";
        document.getElementById('lblq10choice2').innerHTML = "apt-get install";
        document.getElementById('lblq10choice3').innerHTML = "pip install";
        document.getElementById('lblq10choice4').innerHTML = "gem install";

    }
}

// GitHub quiz
function github()
{
    var git = document.getElementById('languages');
    if(git.selectedIndex == 18)
    {
        // first question
        document.getElementById('question1').innerHTML = "Q1. What is GitHub primarily used for?";
        document.getElementById('lblq1choice1').innerHTML = "Video conferencing";
        document.getElementById('lblq1choice2').innerHTML = "Software development and version control";
        document.getElementById('lblq1choice3').innerHTML = "Online shopping";
        document.getElementById('lblq1choice4').innerHTML = "Social networking";

        // second question
        document.getElementById('question2').innerHTML = "Q2. What is a `repository` on GitHub?";
        document.getElementById('lblq2choice1').innerHTML = "A place to store multimedia files";
        document.getElementById('lblq2choice2').innerHTML = "A central location where code, files, and documentation for a project are stored";
        document.getElementById('lblq2choice3').innerHTML = "A tool for managing schedules";
        document.getElementById('lblq2choice4').innerHTML = "A database for storing customer information";

        // third question
        document.getElementById('question3').innerHTML = "Q3. Which of the following is a benefit of using GitHub for open-source projects?";
        document.getElementById('lblq3choice1').innerHTML = "Limited collaboration features";
        document.getElementById('lblq3choice2').innerHTML = "Closed-source nature";
        document.getElementById('lblq3choice3').innerHTML = "Enhanced collaboration and version control";
        document.getElementById('lblq3choice4').innerHTML = "Expensive subscription fees"; 

        // fourth question
        document.getElementById('question4').innerHTML = "Q4. What does `forking` a repository mean on GitHub?";
        document.getElementById('lblq4choice1').innerHTML = "Deleting a repository";
        document.getElementById('lblq4choice2').innerHTML = "Creating a copy of another user's repository to make changes without affecting the original";
        document.getElementById('lblq4choice3').innerHTML = "Merging two branches";
        document.getElementById('lblq4choice4').innerHTML = "Adding a new collaborator to the repository";

        // fifth question
        document.getElementById('question5').innerHTML = "Q5. GitHub is built on which version control system?";
        document.getElementById('lblq5choice1').innerHTML = "Subversion";
        document.getElementById('lblq5choice2').innerHTML = "Git";
        document.getElementById('lblq5choice3').innerHTML = "Mercurial";
        document.getElementById('lblq5choice4').innerHTML = "CVS";
    
        // sixth question
        document.getElementById('question6').innerHTML = "Q6. What does the 'README' file in a GitHub repository typically contain?";
        document.getElementById('lblq6choice1').innerHTML = "A list of all contributors";
        document.getElementById('lblq6choice2').innerHTML = "The project’s documentation, including an overview, installation instructions, and usage information";
        document.getElementById('lblq6choice3').innerHTML = "Source code";
        document.getElementById('lblq6choice4').innerHTML = "A list of issues and bugs";
    
        //seventh question
        document.getElementById('question7').innerHTML = "Q7. Which of the following is NOT a feature of GitHub?";
        document.getElementById('lblq7choice1').innerHTML = "Issue tracking";
        document.getElementById('lblq7choice2').innerHTML = "Code hosting";
        document.getElementById('lblq7choice3').innerHTML = "Video conferencing";
        document.getElementById('lblq7choice4').innerHTML = "Collaboration tools";

        //Eighth question
        document.getElementById('question8').innerHTML = "Q8. How do you propose changes to a repository in GitHub?";
        document.getElementById('lblq8choice1').innerHTML = "By creating a pull request";
        document.getElementById('lblq8choice2').innerHTML = "By deleting the repository";
        document.getElementById('lblq8choice3').innerHTML = "By creating a clone";
        document.getElementById('lblq8choice4').innerHTML = "By forking the repository";

        //Ninth question
        document.getElementById('question9').innerHTML = "Q9. Which feature allows developers to discuss bugs and enhancements?";
        document.getElementById('lblq9choice1').innerHTML = "Branches";
        document.getElementById('lblq9choice2').innerHTML = "Commits";
        document.getElementById('lblq9choice3').innerHTML = "Issues";
        document.getElementById('lblq9choice4').innerHTML = "Forks";

        //Tenth question
        document.getElementById('question10').innerHTML = "10. What is a 'commit' in GitHub?";
        document.getElementById('lblq10choice1').innerHTML = "A backup of the entire repository";
        document.getElementById('lblq10choice2').innerHTML = "A saved change or set of changes to the repository";
        document.getElementById('lblq10choice3').innerHTML = "A branch of the repository";
        document.getElementById('lblq10choice4').innerHTML = "A pull request";

    }
}

// Python quiz
function python()
{
    var Python = document.getElementById('languages');
    if(Python.selectedIndex == 19)
    {
        // first question
        document.getElementById('question1').innerHTML = "Q1. Python is known as:";
        document.getElementById('lblq1choice1').innerHTML = "A compiled language";
        document.getElementById('lblq1choice2').innerHTML = "An interpreted language";
        document.getElementById('lblq1choice3').innerHTML = "A machine language";
        document.getElementById('lblq1choice4').innerHTML = "An assembly language";

        // second question
        document.getElementById('question2').innerHTML = "Q2. Which of the following is a valid Python comment?";
        document.getElementById('lblq2choice1').innerHTML = "<!---->";
        document.getElementById('lblq2choice2').innerHTML = "/* */";
        document.getElementById('lblq2choice3').innerHTML = "#";
        document.getElementById('lblq2choice4').innerHTML = "//";

        // third question
        document.getElementById('question3').innerHTML = "Q3. Python is a:";
        document.getElementById('lblq3choice1').innerHTML = "Low-level language";
        document.getElementById('lblq3choice2').innerHTML = "High-level language";
        document.getElementById('lblq3choice3').innerHTML = "Middle-level language";
        document.getElementById('lblq3choice4').innerHTML = "Machine-level language"; 

        // fourth question
        document.getElementById('question4').innerHTML = "Q4. What data type would you use to store a whole number in Python?";
        document.getElementById('lblq4choice1').innerHTML = "int";
        document.getElementById('lblq4choice2').innerHTML = "float";
        document.getElementById('lblq4choice3').innerHTML = "str";
        document.getElementById('lblq4choice4').innerHTML = "bool";

        // fifth question
        document.getElementById('question5').innerHTML = "Q5. What does the sep parameter do in the print() function?";
        document.getElementById('lblq5choice1').innerHTML = "Separates lines";
        document.getElementById('lblq5choice2').innerHTML = "Specifies separator between values";
        document.getElementById('lblq5choice3').innerHTML = "Separates syntax errors";
        document.getElementById('lblq5choice4').innerHTML = "None of these";
    
        // sixth question
        document.getElementById('question6').innerHTML = "Q6. What is the purpose of an if statement in Python?";
        document.getElementById('lblq6choice1').innerHTML = "To loop through a sequence";
        document.getElementById('lblq6choice2').innerHTML = "To execute a block conditionally";
        document.getElementById('lblq6choice3').innerHTML = "To define a function";
        document.getElementById('lblq6choice4').innerHTML = "To handle exceptions";
    
        //seventh question
        document.getElementById('question7').innerHTML = "Q7. Which statement immediately terminates a loop in Python?";
        document.getElementById('lblq7choice1').innerHTML = "break";
        document.getElementById('lblq7choice2').innerHTML = "continue";
        document.getElementById('lblq7choice3').innerHTML = "exit";
        document.getElementById('lblq7choice4').innerHTML = "stop";

        //Eighth question
        document.getElementById('question8').innerHTML = "Q8. What is the main difference between a list and a tuple in Python?";
        document.getElementById('lblq8choice1').innerHTML = "Syntax";
        document.getElementById('lblq8choice2').innerHTML = "Data type";
        document.getElementById('lblq8choice3').innerHTML = "Mutability";
        document.getElementById('lblq8choice4').innerHTML = "Method of declaration";

        //Ninth question
        document.getElementById('question9').innerHTML = "Q9. What is the main difference between threading and multiprocessing in Python?";
        document.getElementById('lblq9choice1').innerHTML = "Threading is faster";
        document.getElementById('lblq9choice2').innerHTML = "Multiprocessing uses more memory";
        document.getElementById('lblq9choice3').innerHTML = "Threading involves parallel execution";
        document.getElementById('lblq9choice4').innerHTML = "Multiprocessing involves separate memory spaces for each process";

        //Tenth question
        document.getElementById('question10').innerHTML = "10. What is a regular expression used for in Python?";
        document.getElementById('lblq10choice1').innerHTML = "Error handling";
        document.getElementById('lblq10choice2').innerHTML = "Data serialization";
        document.getElementById('lblq10choice3').innerHTML = "Pattern matching and text";
        document.getElementById('lblq10choice4').innerHTML = "Memory management";

    }
}

// Django quiz
function django()
{
    var Django = document.getElementById('languages');
    if(Django.selectedIndex == 20)
    {
        // first question
        document.getElementById('question1').innerHTML = "Q1. Django is a Python-based ____.";
        document.getElementById('lblq1choice1').innerHTML = "web framework";
        document.getElementById('lblq1choice2').innerHTML = "video creating tool";
        document.getElementById('lblq1choice3').innerHTML = "analysis tool";
        document.getElementById('lblq1choice4').innerHTML = "desktop development platform";

        // second question
        document.getElementById('question2').innerHTML = "Q2. Django is maintained by which organization/company?";
        document.getElementById('lblq2choice1').innerHTML = "Oracle";
        document.getElementById('lblq2choice2').innerHTML = "Microsoft Corporation";
        document.getElementById('lblq2choice3').innerHTML = "Python Software Foundation";
        document.getElementById('lblq2choice4').innerHTML = "Django Software Foundation";

        // third question
        document.getElementById('question3').innerHTML = "Q3. Which is the correct command to start the Django development server on your system?";
        document.getElementById('lblq3choice1').innerHTML = "py manage.py localhost";
        document.getElementById('lblq3choice2').innerHTML = "py manage.py runatserver";
        document.getElementById('lblq3choice3').innerHTML = "py manage.py createserver";
        document.getElementById('lblq3choice4').innerHTML = "py manage.py runserver"; 

        // fourth question
        document.getElementById('question4').innerHTML = "Q4. Django is written in which language?";
        document.getElementById('lblq4choice1').innerHTML = "C++";
        document.getElementById('lblq4choice2').innerHTML = "Python";
        document.getElementById('lblq4choice3').innerHTML = "AngularJS";
        document.getElementById('lblq4choice4').innerHTML = "Asp.Net";

        // fifth question
        document.getElementById('question5').innerHTML = "Q5. What is the correct syntax to use a variable in the Django template?";
        document.getElementById('lblq5choice1').innerHTML = "{{ variable_name }}";
        document.getElementById('lblq5choice2').innerHTML = "< variable_name >";
        document.getElementById('lblq5choice3').innerHTML = "<< variable_name >>";
        document.getElementById('lblq5choice4').innerHTML = "`variable_name`";
    
        // sixth question
        document.getElementById('question6').innerHTML = "Q6.  Which Django tag is used to write comments?";
        document.getElementById('lblq6choice1').innerHTML = "{% startcomment %} ... {% endcomment %}";
        document.getElementById('lblq6choice2').innerHTML = "{% comment %} ... {% endcomment %}";
        document.getElementById('lblq6choice3').innerHTML = "{% initcomment %} ... {% endcomment %}";
        document.getElementById('lblq6choice4').innerHTML = "{% start %} ... {% end %}";
    
        //seventh question
        document.getElementById('question7').innerHTML = "Q7. In Django QuertSet, which method is used to filter your search?";
        document.getElementById('lblq7choice1').innerHTML = "filter()";
        document.getElementById('lblq7choice2').innerHTML = "search()";
        document.getElementById('lblq7choice3').innerHTML = "filter_all()";
        document.getElementById('lblq7choice4').innerHTML = "filter_values()";

        //Eighth question
        document.getElementById('question8').innerHTML = "Q8. Django is a type of";
        document.getElementById('lblq8choice1').innerHTML = "Tool";
        document.getElementById('lblq8choice2').innerHTML = "Software";
        document.getElementById('lblq8choice3').innerHTML = "Web framework";
        document.getElementById('lblq8choice4').innerHTML = "Programming Language";

        //Ninth question
        document.getElementById('question9').innerHTML = "Q9. What are the features available in Django web framework?";
        document.getElementById('lblq9choice1').innerHTML = "Form handling";
        document.getElementById('lblq9choice2').innerHTML = "Templating";
        document.getElementById('lblq9choice3').innerHTML = "Admin Interface (CRUD)";
        document.getElementById('lblq9choice4').innerHTML = "All of the above";

        //Tenth question
        document.getElementById('question10').innerHTML = "10. View response can be the ?";
        document.getElementById('lblq10choice1').innerHTML = "404 error";
        document.getElementById('lblq10choice2').innerHTML = "XML document";
        document.getElementById('lblq10choice3').innerHTML = "HTML contents";
        document.getElementById('lblq10choice4').innerHTML = "All of the above";

    }
}

function java()
{
    var Java = document.getElementById('languages');
    if(Java.selectedIndex == 21)
    {
        // first question
        document.getElementById('question1').innerHTML = "Q1. JDK stands for ____.";
        document.getElementById('lblq1choice1').innerHTML = "Java development kit";
        document.getElementById('lblq1choice2').innerHTML = "Java deployment kit";
        document.getElementById('lblq1choice3').innerHTML = "JavaScript deployment kit";
        document.getElementById('lblq1choice4').innerHTML = "None of these";

        // second question
        document.getElementById('question2').innerHTML = "Q2. What makes the Java platform independent?";
        document.getElementById('lblq2choice1').innerHTML = "Advanced programming language";
        document.getElementById('lblq2choice2').innerHTML = "It uses bytecode for execution";
        document.getElementById('lblq2choice3').innerHTML = "Class compilation";
        document.getElementById('lblq2choice4').innerHTML = "All of these";

        // third question
        document.getElementById('question3').innerHTML = "Q3. Can the Java program accept input from the command line?";
        document.getElementById('lblq3choice1').innerHTML = "Yes, using command-line arguments";
        document.getElementById('lblq3choice2').innerHTML = "Yes, by access command prompt";
        document.getElementById('lblq3choice3').innerHTML = "No";
        document.getElementById('lblq3choice4').innerHTML = "None of these"; 

        // fourth question
        document.getElementById('question4').innerHTML = "Q4. Wrapper class in java is ___.";
        document.getElementById('lblq4choice1').innerHTML = "Used to encapsulate primitive data types";
        document.getElementById('lblq4choice2').innerHTML = "Declare new classes called wrapper";
        document.getElementById('lblq4choice3').innerHTML = "Create a new instance of the class";
        document.getElementById('lblq4choice4').innerHTML = "None of these";

        // fifth question
        document.getElementById('question5').innerHTML = "Q5.  Which method in java is used to generate random numbers in Java?";
        document.getElementById('lblq5choice1').innerHTML = "random.nextInt()";
        document.getElementById('lblq5choice2').innerHTML = "random()";
        document.getElementById('lblq5choice3').innerHTML = "rand()";
        document.getElementById('lblq5choice4').innerHTML = "All of these";
    
        // sixth question
        document.getElementById('question6').innerHTML = "Q6. Which of these is true for interfaces in java?";
        document.getElementById('lblq6choice1').innerHTML = "The keyword interface is used to create a method";
        document.getElementById('lblq6choice2').innerHTML = "All the methods of an interface are abstract";
        document.getElementById('lblq6choice3').innerHTML = "It does not contain constructors";
        document.getElementById('lblq6choice4').innerHTML = "All of these";
    
        //seventh question
        document.getElementById('question7').innerHTML = "Q7. Which of the following statements is not correct for vectors in Java?";
        document.getElementById('lblq7choice1').innerHTML = "It was created using vector keyword";
        document.getElementById('lblq7choice2').innerHTML = "It can store an object of different classes";
        document.getElementById('lblq7choice3').innerHTML = "It is asynchronous";
        document.getElementById('lblq7choice4').innerHTML = "None of these";

        //Eighth question
        document.getElementById('question8').innerHTML = "Q8. Batch processing in java is ___.";
        document.getElementById('lblq8choice1').innerHTML = "Used to execute a group of queries or a batch as executing a single query, again and again, is time taking and reduce the performance";
        document.getElementById('lblq8choice2').innerHTML = "Used to processing multiple queries can be executed at once";
        document.getElementById('lblq8choice3').innerHTML = "Used to increase program's performance";
        document.getElementById('lblq8choice4').innerHTML = "All of these";

        //Ninth question
        document.getElementById('question9').innerHTML = "Q9. Which of the following inheritance of class is invalid in Java?";
        document.getElementById('lblq9choice1').innerHTML = "Single";
        document.getElementById('lblq9choice2').innerHTML = "Multiple";
        document.getElementById('lblq9choice3').innerHTML = "Multi-level";
        document.getElementById('lblq9choice4').innerHTML = "Hierarchical";

        //Tenth question
        document.getElementById('question10').innerHTML = "10. What are packages in Java?";
        document.getElementById('lblq10choice1').innerHTML = "Methods of a friend class";
        document.getElementById('lblq10choice2').innerHTML = "Methods of the main class";
        document.getElementById('lblq10choice3').innerHTML = "Way to encapsulate a group of classes, sub-packages, and interface";
        document.getElementById('lblq10choice4').innerHTML = "All of these";

    }
}