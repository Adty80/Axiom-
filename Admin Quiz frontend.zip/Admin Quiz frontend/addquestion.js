var msg = document.getElementById('msg');

document.getElementById('msg').style.display = "none";

// validation for blank 
function checkinput()
{
    var txtques = document.getElementById('txtques').value;
    
    var quesmsg = document.getElementById('quesmsg');
    var txtcans = document.getElementById('txtcans').value;
    
    var cansmsg = document.getElementById('cansmsg');
    var txtoption1 = document.getElementById('txtoption1').value;
    var opt1msg = document.getElementById('opt1msg');
    var txtoption2 = document.getElementById('txtoption2').value;
    var opt2smsg = document.getElementById('opt2msg');
    var txtoption3 = document.getElementById('txtoption3').value;
    var opt3msg = document.getElementById('opt3msg');
    var txtoption4 = document.getElementById('txtoption4').value;
    var opt4msg = document.getElementById('opt4msg');

    if(txtques == "")
    {
        document.getElementById('quesmsg').innerHTML = "Question required";
        return false;
    }
    else
    {
        document.getElementById('quesmsg').innerHTML = "";
    }

    if(txtcans == "")
    {
        document.getElementById('cansmsg').innerHTML = "Correct answer required";
        return false;
    }
    else
    {
        document.getElementById('cansmsg').innerHTML = "";
    }

    if(txtoption1 == "")
    {
        document.getElementById('opt1msg').innerHTML = "Option A required";
        return false;
    }
    else
    {
        document.getElementById('opt1msg').innerHTML = "";
    }

    if(txtoption2 == "")
    {
        document.getElementById('opt2msg').innerHTML = "Option B required";
        return false;
    }
    else
    {
        document.getElementById('opt2msg').innerHTML = "";
    }
    
    if(txtoption3 == "")
    {
        document.getElementById('opt3msg').innerHTML = "Option C required";
        return false;
    }
    else
    {
        document.getElementById('opt3msg').innerHTML = "";
    }

    if(txtoption4 == "")
    {            
        document.getElementById('opt4msg').innerHTML = "Option D required";
        return false;
    }
    else
    {
        document.getElementById('opt4msg').innerHTML = "";
    }
}

//validation for submit 
function submitform()
{
    var txtques = document.getElementById('txtques').value;
    
    var quesmsg = document.getElementById('quesmsg');
    var txtcans = document.getElementById('txtcans').value;
    
    var cansmsg = document.getElementById('cansmsg');
    var txtoption1 = document.getElementById('txtoption1').value;
    var opt1msg = document.getElementById('opt1msg');
    var txtoption2 = document.getElementById('txtoption2').value;
    var opt2smsg = document.getElementById('opt2msg');
    var txtoption3 = document.getElementById('txtoption3').value;
    var opt3msg = document.getElementById('opt3msg');
    var txtoption4 = document.getElementById('txtoption4').value;
    var opt4msg = document.getElementById('opt4msg');
    var msg = document.getElementById('msg');

    if(txtques == "")
    {
        document.getElementById('quesmsg').innerHTML = "Question required";
        return false;
    }
    else
    {
        document.getElementById('quesmsg').innerHTML = "";
    }

    if(txtcans == "")
    {
        document.getElementById('cansmsg').innerHTML = "Correct answer required";
        return false;
    }
    else
    {
        document.getElementById('cansmsg').innerHTML = "";
    }

    if(txtoption1 == "")
    {
        document.getElementById('opt1msg').innerHTML = "Option1 required";
        return false;
    }
    else
    {
        document.getElementById('opt1msg').innerHTML = "";
    }

    if(txtoption2 == "")
    {
        document.getElementById('opt2msg').innerHTML = "Option2 required";
        return false;
    }
    else
    {
        document.getElementById('opt2msg').innerHTML = "";
    }
    
    if(txtoption3 == "")
    {
        document.getElementById('opt3msg').innerHTML = "Option3 required";
        return false;
    }
    else
    {
        document.getElementById('opt3msg').innerHTML = "";
    }

    if(txtoption4 == "")
    {            
        document.getElementById('opt4msg').innerHTML = "Option4 required";
        return false;
    }
    else
    {
        document.getElementById('opt4msg').innerHTML = "";
    }   
}

//Modal successfully submit when save button is click after form submit
var forms = document.getElementById('forms');
var msg = document.getElementById('msg');
var done = document.getElementById('done');
document.getElementById('forms').addEventListener('submit', function(event)
{
    event.preventDefault();
    document.getElementById('msg').style.display = "block";
     
});

done.addEventListener('click', ()=>
{
    document.getElementById('msg').style.display = "none";
});

        //Edit question when edit button is click
        var btnicon1 = document.getElementById('btnicon1');
        var edit = document.getElementById('edit');
        var txtques = document.getElementById('txtques').value;
        var editmsg = document.getElementById('editmsg');
        var editclose = document.getElementById('editclose');
        btnicon1.addEventListener('click', ()=>
        {
            document.getElementById('edit').style.display = "block"; 
            document.getElementById('editmsg').innerHTML = "Question Edited Successfully";   
        });

        editclose.addEventListener('click', ()=>
        {
            document.getElementById('edit').style.display = "none";
        });
        

        //Edit correct answer when edit button is click
        var btnicon2 = document.getElementById('btnicon2');
        var txtcans = document.getElementById('txtcans').value;
        var edit = document.getElementById('edit');
        var editmsg = document.getElementById('editmsg');
        var editclose = document.getElementById('editclose');
        btnicon2.addEventListener('click', ()=>
        {
            document.getElementById('edit').style.display = "block";
            document.getElementById('editmsg').innerHTML = "Answer Edited Successfully";
        });

        editclose.addEventListener('click', ()=>
        {
            document.getElementById('edit').style.display = "none";
        });

        //option1 edited when edit button is click
        var btnicon3 = document.getElementById('btnicon3');
        var txtoption1 = document.getElementById('txtoption1').value;
        var edit = document.getElementById('edit');
        var editmsg = document.getElementById('editmsg');
        var editclose = document.getElementById('editclose');
        btnicon3.addEventListener('click', ()=>
        {
            document.getElementById('edit').style.display = "block";
            document.getElementById('editmsg').innerHTML = "Option A Edited";
        });

        editclose.addEventListener('click', ()=>
        {
            document.getElementById('edit').style.display = "none";
        });

        //option2 edited when edit button is click
        var btnicon4 = document.getElementById('btnicon4');
        var txtoption2 = document.getElementById('txtoption2').value;
        var edit = document.getElementById('edit');
        var editmsg = document.getElementById('editmsg');
        var editclose = document.getElementById('editclose');
        btnicon4.addEventListener('click', ()=>
        {
            document.getElementById('edit').style.display = "block";
            document.getElementById('editmsg').innerHTML = "Option B Edited";
        });

        editclose.addEventListener('click', ()=>
        {
            document.getElementById('edit').style.display = "none";
        });

        //option3 edited when edit button is click
        var btnicon5 = document.getElementById('btnicon5');
        var txtoption3 = document.getElementById('txtoption3').value;
        var edit = document.getElementById('edit');
        var editmsg = document.getElementById('editmsg');
        var editclose = document.getElementById('editclose');
        btnicon5.addEventListener('click', ()=>
        {
            document.getElementById('edit').style.display = "block";
            document.getElementById('editmsg').innerHTML = "Option C Edited";
        });

        editclose.addEventListener('click', ()=>
        {
            document.getElementById('edit').style.display = "none";
        });

        //option4 edited when edit button is click
        var btnicon6 = document.getElementById('btnicon6');
        var txtoption4 = document.getElementById('txtoption4').value;
        var edit = document.getElementById('edit');
        var editmsg = document.getElementById('editmsg');
        var editclose = document.getElementById('editclose');
        btnicon6.addEventListener('click', ()=>
        {
            document.getElementById('edit').style.display = "block";
            document.getElementById('editmsg').innerHTML = "Option D Edited";
        });

        editclose.addEventListener('click', ()=>
        {
            document.getElementById('edit').style.display = "none";
        });

